//Copy your Dice class from Dice.js here.
//You will then be able to use it to solve
//the rest of the exercise.

//top-level function 
function rollSum(n, sum) {
    //roll n dice until you hit sum
    //return the number of rolls it took 

};


function displayFiveDiceRoll(arrDice){

    //display the corresponding die images
    //which represent the die rolls in the 
    //given array, arrDice, in the HTML table

    //use the following jQuery: $(selector).attr(src,file_path)

};

function rollTheDice(){

    //check if user entered a sum to roll 


    //if sum to roll was not entered

        //roll 5 dice


        //display the corresponding die images

        
        //report the sum rolled in a div


    //otherwise

        //roll until you hit the sum to roll input by the user


        //display the corresponding die images

        //report how many rolls it took to get the sum in a div
    
};


$(document).ready(function(){

  //display the default image on each die, on the HTML page
  //use the following jQuery: $(selector).attr(src,file_path)




  //using jQuery, register a handler, rollTheDice() 
  //to the Roll'em! button


});

